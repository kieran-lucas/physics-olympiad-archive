European Physics Olympiad 2022, problem 3: T3: Dipole in a magnetic field

LaTeX transcription of the official paper (problem),
copied as printed, by olimpicos.net. Figures are cropped from the original PDF.
The problems and solutions are the olympiad's own material.
Compile with pdflatex, xelatex or tectonic.
