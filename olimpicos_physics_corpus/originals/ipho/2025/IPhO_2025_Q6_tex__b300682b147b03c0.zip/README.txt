International Physics Olympiad 2025, problem 6: Strongly correlated Fermi gases

LaTeX transcription of the official paper (problem),
copied as printed, by olimpicos.net. Figures are cropped from the original PDF.
The problems and solutions are the olympiad's own material.
Compile with pdflatex, xelatex or tectonic.
