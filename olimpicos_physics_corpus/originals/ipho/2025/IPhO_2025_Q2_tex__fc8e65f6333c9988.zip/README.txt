International Physics Olympiad 2025, problem 2: Cox's Timepiece

LaTeX transcription of the official paper (problem, solution),
copied as printed, by olimpicos.net. Figures are cropped from the original PDF.
The problems and solutions are the olympiad's own material.
Compile with pdflatex, xelatex or tectonic.
