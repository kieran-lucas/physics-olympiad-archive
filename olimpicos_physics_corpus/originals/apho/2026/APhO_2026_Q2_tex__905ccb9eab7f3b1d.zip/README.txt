Asian Physics Olympiad 2026, problem 2: Diffraction of X-rays by Structured and Evolving Targets

LaTeX transcription of the official paper (problem),
copied as printed, by olimpicos.net. Figures are cropped from the original PDF.
The problems and solutions are the olympiad's own material.
Compile with pdflatex, xelatex or tectonic.
