European Physics Olympiad 2017, problem 3: Superconducting mesh

LaTeX transcription of the official paper (problem, solution),
copied as printed, by olimpicos.net. Figures are cropped from the original PDF.
The problems and solutions are the olympiad's own material.
Compile with pdflatex, xelatex or tectonic.
